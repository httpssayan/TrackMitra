import { Bot, TrendingUp, Clock, CheckCircle, AlertCircle, Zap, Battery } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface KPI {
  id: string;
  title: string;
  titleHi: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'stable';
  icon: React.ComponentType<any>;
  color: string;
}

interface AIDecision {
  id: string;
  type: 'recommendation' | 'alert' | 'action';
  title: string;
  titleHi: string;
  description: string;
  descriptionHi: string;
  confidence: number;
  priority: 'high' | 'medium' | 'low';
  timestamp: string;
}

const kpis: KPI[] = [
  {
    id: '1',
    title: 'Avg Delay',
    titleHi: 'औसत देरी',
    value: '8.5 min',
    change: '-2.3',
    trend: 'down',
    icon: Clock,
    color: 'text-yellow-600'
  },
  {
    id: '2',
    title: 'Throughput',
    titleHi: 'थ्रूपुट',
    value: '24 trains/hr',
    change: '+3.2',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-green-600'
  },
  {
    id: '3',
    title: 'On-time %',
    titleHi: 'समय पर %',
    value: '87.3%',
    change: '+1.8',
    trend: 'up',
    icon: CheckCircle,
    color: 'text-[#0A3D62]'
  },
  {
    id: '4',
    title: 'Energy Consumption 🔋',
    titleHi: 'ऊर्जा खपत',
    value: '1540 units',
    change: '-1.2',
    trend: 'down',
    icon: Battery,
    color: 'text-green-600'
  }
];

const aiDecisions: AIDecision[] = [
  {
    id: '1',
    type: 'alert',
    title: 'Track Conflict Detected',
    titleHi: 'ट्रैक संघर्ष का पता लगा',
    description: 'Trains 13308 & 54254 approaching same block',
    descriptionHi: 'ट्रेन 13308 और 54254 एक ही ब्लॉक में आ रही हैं',
    confidence: 95,
    priority: 'high',
    timestamp: '14:23:15'
  },
  {
    id: '2',
    type: 'recommendation',
    title: 'Route Optimization',
    titleHi: 'मार्ग अनुकूलन',
    description: 'Divert BOXN freight to avoid express delays',
    descriptionHi: 'एक्सप्रेस की देरी से बचने के लिए माल गाड़ी को मोड़ें',
    confidence: 87,
    priority: 'medium',
    timestamp: '14:22:48'
  },
  {
    id: '3',
    type: 'action',
    title: 'Signal Override Required',
    titleHi: 'सिग्नल ओवरराइड आवश्यक',
    description: 'Manual intervention needed at ALG junction',
    descriptionHi: 'ALG जंक्शन पर मैन्युअल हस्तक्षेप की आवश्यकता',
    confidence: 92,
    priority: 'high',
    timestamp: '14:21:33'
  }
];

function getPriorityColor(priority: string) {
  switch (priority) {
    case 'high':
      return 'bg-red-100 text-red-800 border-red-200';
    case 'medium':
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'low':
      return 'bg-green-100 text-green-800 border-green-200';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

function getTypeIcon(type: string) {
  switch (type) {
    case 'alert':
      return <AlertCircle className="h-4 w-4" />;
    case 'recommendation':
      return <Zap className="h-4 w-4" />;
    case 'action':
      return <Bot className="h-4 w-4" />;
    default:
      return <Bot className="h-4 w-4" />;
  }
}

interface AIDecisionPanelProps {
  isCollapsed?: boolean;
}

export function AIDecisionPanel({ isCollapsed = false }: AIDecisionPanelProps) {
  return (
    <div className="h-full bg-[#F7F9FB] overflow-auto rounded-lg shadow-lg">
      {/* AI Decisions Section */}
      <div className="p-4 bg-gradient-to-r from-[#0A3D62] to-[#134E7C] text-white">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5 text-[#FF6B00]" />
          <h2 className="font-semibold">{isCollapsed ? 'AI' : 'AI Decisions'}</h2>
        </div>
        {!isCollapsed && <p className="text-sm text-blue-100">AI निर्णय सहायता</p>}
      </div>
      
      <div className="p-3 space-y-3">
        {aiDecisions.map((decision) => (
          <Card key={decision.id} className="border-l-4 border-l-[#FF6B00] shadow-md bg-white border border-gray-200 hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer group">
            <CardContent className="p-3">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getTypeIcon(decision.type)}
                  <Badge className={`${getPriorityColor(decision.priority)} group-hover:shadow-md transition-shadow`}>
                    {decision.priority}
                  </Badge>
                </div>
                <span className="text-xs text-gray-500">{decision.timestamp}</span>
              </div>
              
              <div className="space-y-2">
                <div>
                  <h4 className="font-medium text-[#0A3D62] text-sm group-hover:text-[#FF6B00] transition-colors">{decision.title}</h4>
                  {!isCollapsed && <p className="text-xs text-gray-600">{decision.titleHi}</p>}
                </div>
                
                {!isCollapsed && (
                  <div>
                    <p className="text-sm text-gray-700">{decision.description}</p>
                    <p className="text-xs text-gray-500">{decision.descriptionHi}</p>
                  </div>
                )}
                
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-600">Confidence:</span>
                  <Progress value={decision.confidence} className="flex-1 h-2" />
                  <span className="text-xs font-medium">{decision.confidence}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* KPI Section */}
      <div className="p-3 bg-gradient-to-r from-[#0A3D62] to-[#134E7C] text-white border-t-2 border-[#FF6B00]">
        <h3 className="font-semibold mb-1">{isCollapsed ? 'KPIs' : 'Performance KPIs'}</h3>
        {!isCollapsed && <p className="text-sm text-blue-100">प्रदर्शन संकेतक</p>}
      </div>
      
      <div className="p-3 space-y-3">
        {kpis.map((kpi) => (
          <Card key={kpi.id} className="shadow-md bg-white border border-gray-200 hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer group">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <kpi.icon className={`h-4 w-4 ${kpi.color} group-hover:scale-110 transition-transform`} />
                  {!isCollapsed && (
                    <div>
                      <h4 className="font-medium text-sm group-hover:text-[#0A3D62] transition-colors">{kpi.title}</h4>
                      <p className="text-xs text-gray-500">{kpi.titleHi}</p>
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className="font-semibold text-lg group-hover:text-[#FF6B00] transition-colors">{kpi.value}</div>
                  <div className={`text-xs flex items-center gap-1 ${
                    kpi.trend === 'up' ? 'text-green-600' : 
                    kpi.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {kpi.trend === 'up' ? '↗' : kpi.trend === 'down' ? '↘' : '→'}
                    <span>{kpi.change}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* System Status */}
      <div className="p-3 border-t-2 border-[#FF6B00]">
        <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-300 shadow-md hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="p-3">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="font-medium text-green-800">{isCollapsed ? 'Active' : 'System Active'}</span>
            </div>
            {!isCollapsed && (
              <div className="text-sm text-green-700">
                <p>AI monitoring: Online</p>
                <p>Last update: 14:23:15 IST</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}