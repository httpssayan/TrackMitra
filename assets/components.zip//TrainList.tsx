import { Clock, Zap, Truck, Users } from 'lucide-react';
import { Badge } from './ui/badge';

interface Train {
  id: string;
  number: string;
  name: string;
  eta: string;
  priority: 'Express' | 'Local' | 'Freight';
  delay: number;
  status: 'on-time' | 'delayed' | 'critical';
}

const trains: Train[] = [
  {
    id: '1',
    number: '12002',
    name: 'Shatabdi Express',
    eta: '14:25',
    priority: 'Express',
    delay: 0,
    status: 'on-time'
  },
  {
    id: '2', 
    number: '15008',
    name: 'LJN-BCN Express',
    eta: '14:42',
    priority: 'Express',
    delay: 12,
    status: 'delayed'
  },
  {
    id: '3',
    number: '54254',
    name: 'GZB-CNB Passenger',
    eta: '15:10',
    priority: 'Local',
    delay: 5,
    status: 'delayed'
  },
  {
    id: '4',
    number: '13308',
    name: 'Gangasagar Exp',
    eta: '15:35',
    priority: 'Express',
    delay: 25,
    status: 'critical'
  },
  {
    id: '5',
    number: 'BOXN',
    name: 'Freight 4521',
    eta: '16:15',
    priority: 'Freight',
    delay: 0,
    status: 'on-time'
  },
  {
    id: '6',
    number: '12004',
    name: 'Lucknow Shatbdi',
    eta: '16:48',
    priority: 'Express',
    delay: 8,
    status: 'delayed'
  }
];

function getPriorityIcon(priority: string) {
  switch (priority) {
    case 'Express':
      return <Zap className="h-4 w-4" />;
    case 'Local':
      return <Users className="h-4 w-4" />;
    case 'Freight':
      return <Truck className="h-4 w-4" />;
    default:
      return null;
  }
}

function getPriorityColor(priority: string) {
  switch (priority) {
    case 'Express':
      return 'bg-[#FF6B00] text-white';
    case 'Local':
      return 'bg-[#0A3D62] text-white';
    case 'Freight':
      return 'bg-gray-600 text-white';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function getStatusColor(status: string) {
  switch (status) {
    case 'on-time':
      return 'bg-green-100 text-green-800';
    case 'delayed':
      return 'bg-yellow-100 text-yellow-800';
    case 'critical':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

interface TrainListProps {
  isCollapsed?: boolean;
}

export function TrainList({ isCollapsed = false }: TrainListProps) {
  return (
    <div className="h-full bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-4 bg-gradient-to-r from-[#0A3D62] to-[#134E7C] text-white">
        <h2 className="font-semibold">{isCollapsed ? 'Trains' : 'Active Trains'}</h2>
        {!isCollapsed && <p className="text-sm text-blue-100">{trains.length} trains tracked</p>}
      </div>
      
      <div className="overflow-auto h-[calc(100%-80px)] bg-[#F7F9FB] p-3">
        <div className="space-y-3">
          {trains.map((train) => (
            <div
              key={train.id}
              className="bg-white border border-gray-200 rounded-xl p-3 hover:shadow-lg transition-all duration-300 hover:border-[#FF6B00] hover:scale-105 cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge className={`${getPriorityColor(train.priority)} group-hover:shadow-md transition-shadow`}>
                    {getPriorityIcon(train.priority)}
                    {!isCollapsed && <span className="ml-1">{train.priority}</span>}
                  </Badge>
                </div>
                <Badge className={`${getStatusColor(train.status)} group-hover:shadow-md transition-shadow`}>
                  {train.delay > 0 ? `+${train.delay}m` : 'On Time'}
                </Badge>
              </div>
              
              <div className="space-y-1">
                <div className="font-medium text-[#0A3D62] group-hover:text-[#FF6B00] transition-colors">{train.number}</div>
                {!isCollapsed && (
                  <>
                    <div className="text-sm text-gray-700">{train.name}</div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="h-4 w-4" />
                      <span>ETA: {train.eta}</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}