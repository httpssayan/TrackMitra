import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const trafficData = [
  { hour: '12', trains: 18 },
  { hour: '13', trains: 22 },
  { hour: '14', trains: 26 },
  { hour: '15', trains: 24 },
  { hour: '16', trains: 20 },
  { hour: '17', trains: 28 }
];

const performanceData = [
  { time: '12:00', onTime: 85 },
  { time: '12:30', onTime: 88 },
  { time: '13:00', onTime: 82 },
  { time: '13:30', onTime: 86 },
  { time: '14:00', onTime: 87 },
  { time: '14:30', onTime: 89 }
];

const trainTypeData = [
  { name: 'Express', value: 45, color: '#0A3D62' },
  { name: 'Local', value: 35, color: '#FF6B00' },
  { name: 'Freight', value: 20, color: '#6B7280' }
];

const speedComplianceData = [
  { section: 'GZB-ALG', compliance: 92 },
  { section: 'ALG-CNB', compliance: 88 },
  { section: 'CNB-END', compliance: 95 }
];

export function MiniCharts() {
  return (
    <div className="grid grid-cols-2 gap-4 mb-4">
      {/* Hourly Traffic */}
      <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4">
        <div className="mb-3">
          <h4 className="font-medium text-sm text-[#0A3D62]">Hourly Traffic</h4>
          <p className="text-xs text-gray-500">घंटेवार यातायात</p>
        </div>
        <div className="h-24">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trafficData}>
              <XAxis dataKey="hour" axisLine={false} tickLine={false} fontSize={10} />
              <YAxis hide />
              <Bar dataKey="trains" fill="#0A3D62" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="text-xs text-gray-600 mt-1">
          Peak: 28 trains at 17:00
        </div>
      </div>

      {/* On-time Performance */}
      <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4">
        <div className="mb-3">
          <h4 className="font-medium text-sm text-[#0A3D62]">On-time Trend</h4>
          <p className="text-xs text-gray-500">समय पर प्रदर्शन</p>
        </div>
        <div className="h-24">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={performanceData}>
              <XAxis dataKey="time" axisLine={false} tickLine={false} fontSize={10} />
              <YAxis hide domain={[80, 95]} />
              <Line 
                type="monotone" 
                dataKey="onTime" 
                stroke="#FF6B00" 
                strokeWidth={2}
                dot={{ fill: '#FF6B00', strokeWidth: 2, r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="text-xs text-gray-600 mt-1">
          Current: 89% (↗ +2%)
        </div>
      </div>

      {/* Train Type Distribution */}
      <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4">
        <div className="mb-3">
          <h4 className="font-medium text-sm text-[#0A3D62]">Train Types</h4>
          <p className="text-xs text-gray-500">ट्रेन प्रकार</p>
        </div>
        <div className="flex items-center">
          <div className="h-16 w-16">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={trainTypeData}
                  dataKey="value"
                  cx="50%"
                  cy="50%"
                  innerRadius={12}
                  outerRadius={24}
                  paddingAngle={2}
                >
                  {trainTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="ml-3 space-y-1">
            {trainTypeData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full" 
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-xs text-gray-600">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Speed Compliance */}
      <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4">
        <div className="mb-3">
          <h4 className="font-medium text-sm text-[#0A3D62]">Speed Compliance</h4>
          <p className="text-xs text-gray-500">गति अनुपालन</p>
        </div>
        <div className="space-y-2">
          {speedComplianceData.map((item) => (
            <div key={item.section}>
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-600">{item.section}</span>
                <span className="text-xs font-medium">{item.compliance}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div 
                  className={`h-1.5 rounded-full ${
                    item.compliance >= 90 ? 'bg-green-500' : 
                    item.compliance >= 85 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${item.compliance}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}