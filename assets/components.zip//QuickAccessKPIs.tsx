import { Battery, Clock, TrendingUp, CheckCircle, AlertTriangle, Zap } from 'lucide-react';
import { Card, CardContent } from './ui/card';

interface QuickKPI {
  id: string;
  title: string;
  titleHi: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'stable';
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
}

const quickKPIs: QuickKPI[] = [
  {
    id: '1',
    title: 'Energy Usage',
    titleHi: 'ऊर्जा खपत',
    value: '1540',
    change: '-1.2',
    trend: 'down',
    icon: Battery,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    id: '2',
    title: 'Energy Savings',
    titleHi: 'ऊर्जा बचत',
    value: '12.5%',
    change: '+2.3',
    trend: 'up',
    icon: Zap,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    id: '3',
    title: 'Critical Alerts',
    titleHi: 'गंभीर अलर्ट',
    value: '3',
    change: '+1',
    trend: 'up',
    icon: AlertTriangle,
    color: 'text-red-600',
    bgColor: 'bg-red-50'
  },
  {
    id: '4',
    title: 'On-time Performance',
    titleHi: 'समय पर प्रदर्शन',
    value: '87.3%',
    change: '+1.8',
    trend: 'up',
    icon: CheckCircle,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  }
];

export function QuickAccessKPIs() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-white border-b border-gray-200">
      {quickKPIs.map((kpi) => (
        <Card 
          key={kpi.id} 
          className="hover:shadow-md transition-all duration-200 hover:scale-105 cursor-pointer border-l-4 border-l-[#FF6B00]"
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${kpi.bgColor}`}>
                <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-lg text-[#0A3D62]">{kpi.value}</p>
                    <p className="text-sm text-gray-600 truncate">{kpi.title}</p>
                    <p className="text-xs text-gray-500 truncate">{kpi.titleHi}</p>
                  </div>
                  <div className={`text-xs flex items-center gap-1 ${
                    kpi.trend === 'up' ? 'text-green-600' : 
                    kpi.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {kpi.trend === 'up' ? '↗' : kpi.trend === 'down' ? '↘' : '→'}
                    <span>{kpi.change}%</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}