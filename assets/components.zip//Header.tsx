import { ImageWithFallback } from './figma/ImageWithFallback';
import trackMitraLogo from 'figma:asset/2d0c3e45a2f16e3d262cddac86e16258fe6f8ce4.png';

import { Menu, Bell, Settings } from 'lucide-react';

interface HeaderProps {
  onToggleSidebar: () => void;
}

export function Header({ onToggleSidebar }: HeaderProps) {
  return (
    <header className="h-16 bg-gradient-to-r from-[#0A3D62] to-[#134E7C] text-white flex items-center px-6 shadow-xl border-b-2 border-[#FF6B00] rounded-bl-lg rounded-br-lg mx-2 mt-2">
      <div className="flex items-center gap-4">
        <button
          onClick={onToggleSidebar}
          className="p-2 hover:bg-[#FF6B00] rounded-lg transition-colors duration-200 lg:hidden"
        >
          <Menu className="h-5 w-5" />
        </button>
        
        <div className="flex items-center gap-3">
          <div className="h-10 w-auto">
            <ImageWithFallback 
              src={trackMitraLogo} 
              alt="TrackMitra Logo" 
              className="h-10 w-auto object-contain"
            />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-wide">Trackमित्र</h1>
            <p className="text-sm text-blue-100">AI-Powered Railway Traffic Control</p>
          </div>
        </div>
      </div>
      
      <div className="ml-auto flex items-center gap-4">
        <div className="hidden md:block text-right">
          <p className="text-sm font-medium">Control Center</p>
          <p className="text-xs text-blue-100">Northern Railway Zone</p>
        </div>
        
        <div className="flex items-center gap-2">
          <button className="p-2 hover:bg-[#FF6B00] rounded-lg transition-colors duration-200 relative">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
          </button>
          
          <button className="p-2 hover:bg-[#FF6B00] rounded-lg transition-colors duration-200">
            <Settings className="h-5 w-5" />
          </button>
          
          <div className="w-10 h-10 bg-gradient-to-br from-[#FF6B00] to-[#FF8533] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow duration-200 cursor-pointer">
            <span className="text-sm font-medium">NC</span>
          </div>
        </div>
      </div>
    </header>
  );
}