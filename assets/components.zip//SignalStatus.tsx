import { Circle, Square } from 'lucide-react';

interface SignalBlock {
  id: string;
  name: string;
  nameHi: string;
  status: 'green' | 'yellow' | 'red';
  position: number;
  occupied: boolean;
}

const signalBlocks: SignalBlock[] = [
  { id: '1', name: 'GZB-01', nameHi: 'ग़ाज़ियाबाद-01', status: 'green', position: 15, occupied: false },
  { id: '2', name: 'GZB-02', nameHi: 'ग़ाज़ियाबाद-02', status: 'red', position: 25, occupied: true },
  { id: '3', name: 'ALG-01', nameHi: 'अलीगढ़-01', status: 'yellow', position: 45, occupied: false },
  { id: '4', name: 'ALG-02', nameHi: 'अलीगढ़-02', status: 'red', position: 55, occupied: true },
  { id: '5', name: 'CNB-01', nameHi: 'कानपुर-01', status: 'green', position: 75, occupied: false },
  { id: '6', name: 'CNB-02', nameHi: 'कानपुर-02', status: 'green', position: 85, occupied: false }
];

function getSignalColor(status: string) {
  switch (status) {
    case 'green': return 'text-green-500';
    case 'yellow': return 'text-yellow-500'; 
    case 'red': return 'text-red-500';
    default: return 'text-gray-400';
  }
}

function getSignalBg(status: string) {
  switch (status) {
    case 'green': return 'bg-green-100 border-green-300';
    case 'yellow': return 'bg-yellow-100 border-yellow-300';
    case 'red': return 'bg-red-100 border-red-300';
    default: return 'bg-gray-100 border-gray-300';
  }
}

export function SignalStatus() {
  return (
    <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4 mb-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-semibold text-[#0A3D62]">Signal Status</h3>
          <p className="text-sm text-gray-600">सिग्नल स्थिति</p>
        </div>
        <div className="text-xs text-gray-500">Last Update: 14:23 IST</div>
      </div>
      
      <div className="relative mb-2">
        <div className="w-full h-1 bg-gray-200 rounded"></div>
        {signalBlocks.map((signal) => (
          <div
            key={signal.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${signal.position}%`, top: '50%' }}
          >
            <div className={`w-6 h-6 rounded border-2 ${getSignalBg(signal.status)} flex items-center justify-center shadow-sm`}>
              <Circle className={`h-3 w-3 ${getSignalColor(signal.status)} fill-current`} />
            </div>
            <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-center">
              <div className="text-xs font-medium text-gray-700">{signal.name}</div>
              <div className="text-xs text-gray-500">{signal.nameHi}</div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 flex justify-between items-center text-sm">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Circle className="h-3 w-3 text-green-500 fill-current" />
            <span className="text-gray-600">Clear (2)</span>
          </div>
          <div className="flex items-center gap-1">
            <Circle className="h-3 w-3 text-yellow-500 fill-current" />
            <span className="text-gray-600">Caution (1)</span>
          </div>
          <div className="flex items-center gap-1">
            <Circle className="h-3 w-3 text-red-500 fill-current" />
            <span className="text-gray-600">Stop (3)</span>
          </div>
        </div>
        <div className="text-xs text-gray-500">
          <Square className="h-3 w-3 inline text-gray-400" /> Block Occupied
        </div>
      </div>
    </div>
  );
}