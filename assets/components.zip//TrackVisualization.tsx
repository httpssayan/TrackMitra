import { AlertTriangle, ChevronRight, ChevronLeft } from 'lucide-react';
import { Badge } from './ui/badge';
import { SignalStatus } from './SignalStatus';
import { CriticalAlerts } from './CriticalAlerts';
import { MiniCharts } from './MiniCharts';

interface Station {
  id: string;
  name: string;
  nameHi: string;
  position: number; // 0-100 percentage
}

interface TrainPosition {
  id: string;
  name: string;
  position: number;
  track: 1 | 2;
  priority: 'Express' | 'Local' | 'Freight';
  status: 'moving' | 'stopped' | 'conflict';
  direction: 'right' | 'left';
  delay: number; // in minutes
}

const stations: Station[] = [
  { id: '1', name: 'Ghaziabad', nameHi: 'ग़ाज़ियाबाद', position: 0 },
  { id: '2', name: 'Aligarh', nameHi: 'अलीगढ़', position: 50 },
  { id: '3', name: 'Kanpur', nameHi: 'कानपुर', position: 100 }
];

const trainPositions: TrainPosition[] = [
  { id: '1', name: '12002', position: 25, track: 1, priority: 'Express', status: 'moving', direction: 'right', delay: 0 },
  { id: '2', name: '15008', position: 45, track: 2, priority: 'Express', status: 'moving', direction: 'left', delay: 12 },
  { id: '3', name: '54254', position: 55, track: 1, priority: 'Local', status: 'stopped', direction: 'right', delay: 5 },
  { id: '4', name: '13308', position: 52, track: 1, priority: 'Express', status: 'conflict', direction: 'right', delay: 25 },
  { id: '5', name: 'BOXN', position: 75, track: 2, priority: 'Freight', status: 'moving', direction: 'left', delay: 0 }
];

// Railway Track Component
function RailwayTrack({ isConflictZone = false }: { isConflictZone?: boolean }) {
  return (
    <div className="relative h-6">
      {/* Rails */}
      <div className={`absolute top-1 w-full h-1 rounded-full ${isConflictZone ? 'bg-red-400' : 'bg-gray-400'}`}></div>
      <div className={`absolute bottom-1 w-full h-1 rounded-full ${isConflictZone ? 'bg-red-400' : 'bg-gray-400'}`}></div>
      
      {/* Sleepers */}
      <div className="absolute inset-0 flex justify-between items-center">
        {Array.from({ length: 20 }, (_, i) => (
          <div 
            key={i} 
            className={`w-0.5 h-4 rounded ${isConflictZone ? 'bg-red-300' : 'bg-gray-500'}`}
          ></div>
        ))}
      </div>
    </div>
  );
}

// Professional Train Icons
function ExpressTrainIcon({ direction, status }: { direction: 'right' | 'left', status: string }) {
  const getMainColor = () => {
    if (status === 'conflict') return '#DC2626';
    if (status === 'stopped') return '#D97706';
    return '#0A3D62'; // Deep blue base
  };

  const getAccentColor = () => {
    if (status === 'conflict') return '#FEE2E2';
    if (status === 'stopped') return '#FEF3C7';
    return '#0EA5E9'; // Blue accent for high-speed
  };

  return (
    <svg width="36" height="18" viewBox="0 0 36 18" className="drop-shadow-sm">
      {direction === 'right' ? (
        <>
          {/* Main body - sleek aerodynamic shape */}
          <path d="M2 6h28l4 3-4 3H2c-1 0-2-1-2-2V8c0-1 1-2 2-2z" fill={getMainColor()} />
          {/* Windows */}
          <rect x="6" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="12" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="18" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="24" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          {/* Front nose */}
          <path d="M30 9l6 0-2-1.5v3l2-1.5z" fill={getMainColor()} />
          {/* Speed lines */}
          <line x1="4" y1="5" x2="8" y2="5" stroke={getAccentColor()} strokeWidth="1" />
          <line x1="4" y1="13" x2="8" y2="13" stroke={getAccentColor()} strokeWidth="1" />
        </>
      ) : (
        <>
          {/* Main body */}
          <path d="M34 6H6l-4 3 4 3h28c1 0 2-1 2-2V8c0-1-1-2-2-2z" fill={getMainColor()} />
          <rect x="26" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="20" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="14" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <rect x="8" y="7" width="4" height="4" fill={getAccentColor()} rx="1" />
          <path d="M6 9l-6 0 2-1.5v3l-2-1.5z" fill={getMainColor()} />
          <line x1="28" y1="5" x2="32" y2="5" stroke={getAccentColor()} strokeWidth="1" />
          <line x1="28" y1="13" x2="32" y2="13" stroke={getAccentColor()} strokeWidth="1" />
        </>
      )}
    </svg>
  );
}

function LocalTrainIcon({ direction, status }: { direction: 'right' | 'left', status: string }) {
  const getMainColor = () => {
    if (status === 'conflict') return '#DC2626';
    if (status === 'stopped') return '#D97706';
    return '#0A3D62'; // Deep blue base
  };

  const getAccentColor = () => {
    if (status === 'conflict') return '#FEE2E2';
    if (status === 'stopped') return '#FEF3C7';
    return '#FF6B00'; // Saffron accent for local
  };

  return (
    <svg width="32" height="16" viewBox="0 0 32 16" className="drop-shadow-sm">
      {direction === 'right' ? (
        <>
          {/* Main body - boxy commuter design */}
          <rect x="2" y="4" width="26" height="8" fill={getMainColor()} rx="2" />
          {/* Front */}
          <rect x="28" y="6" width="2" height="4" fill={getMainColor()} />
          {/* Windows */}
          <rect x="5" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          <rect x="12" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          <rect x="19" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          {/* Doors */}
          <line x1="10.5" y1="6" x2="10.5" y2="10" stroke={getMainColor()} strokeWidth="1" />
          <line x1="17.5" y1="6" x2="17.5" y2="10" stroke={getMainColor()} strokeWidth="1" />
        </>
      ) : (
        <>
          <rect x="4" y="4" width="26" height="8" fill={getMainColor()} rx="2" />
          <rect x="2" y="6" width="2" height="4" fill={getMainColor()} />
          <rect x="22" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          <rect x="15" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          <rect x="8" y="6" width="5" height="4" fill={getAccentColor()} rx="1" />
          <line x1="21.5" y1="6" x2="21.5" y2="10" stroke={getMainColor()} strokeWidth="1" />
          <line x1="14.5" y1="6" x2="14.5" y2="10" stroke={getMainColor()} strokeWidth="1" />
        </>
      )}
    </svg>
  );
}

function FreightTrainIcon({ direction, status }: { direction: 'right' | 'left', status: string }) {
  const getMainColor = () => {
    if (status === 'conflict') return '#DC2626';
    if (status === 'stopped') return '#D97706';
    return '#6B7280'; // Grey base
  };

  const getAccentColor = () => {
    if (status === 'conflict') return '#FEE2E2';
    if (status === 'stopped') return '#FEF3C7';
    return '#9CA3AF'; // Light grey accent
  };

  return (
    <svg width="40" height="18" viewBox="0 0 40 18" className="drop-shadow-sm">
      {direction === 'right' ? (
        <>
          {/* Locomotive */}
          <rect x="2" y="4" width="8" height="10" fill={getMainColor()} rx="1" />
          <rect x="4" y="6" width="4" height="3" fill={getAccentColor()} rx="0.5" />
          {/* Cargo containers */}
          <rect x="12" y="5" width="8" height="8" fill={getMainColor()} rx="1" />
          <rect x="22" y="5" width="8" height="8" fill={getMainColor()} rx="1" />
          <rect x="32" y="5" width="6" height="8" fill={getMainColor()} rx="1" />
          {/* Container details */}
          <rect x="14" y="7" width="4" height="4" fill={getAccentColor()} />
          <rect x="24" y="7" width="4" height="4" fill={getAccentColor()} />
          <rect x="33" y="7" width="3" height="4" fill={getAccentColor()} />
        </>
      ) : (
        <>
          <rect x="30" y="4" width="8" height="10" fill={getMainColor()} rx="1" />
          <rect x="32" y="6" width="4" height="3" fill={getAccentColor()} rx="0.5" />
          <rect x="20" y="5" width="8" height="8" fill={getMainColor()} rx="1" />
          <rect x="10" y="5" width="8" height="8" fill={getMainColor()} rx="1" />
          <rect x="2" y="5" width="6" height="8" fill={getMainColor()} rx="1" />
          <rect x="22" y="7" width="4" height="4" fill={getAccentColor()} />
          <rect x="12" y="7" width="4" height="4" fill={getAccentColor()} />
          <rect x="4" y="7" width="3" height="4" fill={getAccentColor()} />
        </>
      )}
    </svg>
  );
}

function getTrainIcon(priority: string, direction: 'right' | 'left', status: string) {
  switch (priority) {
    case 'Express':
      return <ExpressTrainIcon direction={direction} status={status} />;
    case 'Local':
      return <LocalTrainIcon direction={direction} status={status} />;
    case 'Freight':
      return <FreightTrainIcon direction={direction} status={status} />;
    default:
      return <LocalTrainIcon direction={direction} status={status} />;
  }
}

function getDelayBadgeColor(delay: number) {
  if (delay === 0) return 'bg-green-100 text-green-800 border-green-300';
  if (delay <= 10) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
  return 'bg-red-100 text-red-800 border-red-300';
}

// Check for conflicts between trains on the same track
function checkConflicts(trains: TrainPosition[]): { start: number, end: number, track: number }[] {
  const conflicts: { start: number, end: number, track: number }[] = [];
  
  for (let track = 1; track <= 2; track++) {
    const trackTrains = trains.filter(t => t.track === track).sort((a, b) => a.position - b.position);
    
    for (let i = 0; i < trackTrains.length - 1; i++) {
      const train1 = trackTrains[i];
      const train2 = trackTrains[i + 1];
      
      // If trains are within 10% distance (considering train length), mark as conflict zone
      const safeDistance = train1.priority === 'Freight' || train2.priority === 'Freight' ? 12 : 8;
      
      if (Math.abs(train2.position - train1.position) < safeDistance) {
        conflicts.push({
          start: Math.min(train1.position, train2.position) - 3,
          end: Math.max(train1.position, train2.position) + 3,
          track: track
        });
      }
    }
  }
  
  return conflicts;
}

export function TrackVisualization() {
  const conflicts = checkConflicts(trainPositions);
  
  return (
    <div className="h-full bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-4 bg-gradient-to-r from-[#0A3D62] to-[#134E7C] text-white">
        <h2 className="font-semibold">Track Visualization</h2>
        <p className="text-sm text-blue-100">Ghaziabad - Aligarh - Kanpur Section</p>
      </div>
      
      <div className="p-3 lg:p-6 h-[calc(100%-80px)] overflow-auto bg-[#F7F9FB]">
        <div className="w-full max-w-none">
          {/* Critical Alerts Banner */}
          <CriticalAlerts />
          
          {/* Signal Status Panel */}
          <SignalStatus />
          {/* Timeline Header */}
          <div className="mb-8">
            <div className="text-sm text-gray-600 mb-2">Current Time: 14:23 IST</div>
            <div className="flex justify-between text-sm text-gray-500 mb-2">
              <span>GZB (0 km)</span>
              <span>Railway Section</span>
              <span>CNB (250 km)</span>
            </div>
            {/* Distance Scale */}
            <div className="relative h-4 bg-gray-100 rounded">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full h-0.5 bg-gray-400"></div>
                {[0, 25, 50, 75, 100].map((pos) => (
                  <div
                    key={pos}
                    className="absolute w-0.5 h-3 bg-gray-600 transform -translate-x-1/2"
                    style={{ left: `${pos}%` }}
                  >
                    <span className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 text-xs text-gray-500">
                      {pos === 0 ? '0' : pos === 25 ? '62' : pos === 50 ? '125' : pos === 75 ? '187' : '250'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Stations Header */}
          <div className="mb-8 relative">
            <div className="flex justify-between items-center">
              {stations.map((station) => (
                <div key={station.id} className="text-center">
                  <div className="w-5 h-5 bg-[#0A3D62] rounded-full mx-auto mb-2 border-3 border-white shadow-lg flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <div className="font-semibold text-sm text-[#0A3D62]">{station.name}</div>
                  <div className="text-xs text-gray-600 font-medium">{station.nameHi}</div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Track 1 (Up Line) */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-4 p-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="w-4 h-4 bg-[#0A3D62] rounded"></div>
              <span className="font-medium text-[#0A3D62]">Track 1 (Up Line)</span>
              <ChevronRight className="h-4 w-4 text-gray-500" />
            </div>
            
            <div className="relative mb-8">
              {/* Conflict zones background - enhanced visibility */}
              {conflicts.filter(c => c.track === 1).map((conflict, index) => (
                <div
                  key={index}
                  className="absolute h-8 bg-red-200 border-2 border-red-400 rounded-lg opacity-60 shadow-lg"
                  style={{
                    left: `${Math.max(0, conflict.start)}%`,
                    width: `${Math.min(100, conflict.end) - Math.max(0, conflict.start)}%`,
                    top: '-1px'
                  }}
                >
                  <div className="absolute inset-0 bg-red-300 rounded-lg animate-pulse opacity-40"></div>
                </div>
              ))}
              
              {/* Railway Track */}
              <RailwayTrack isConflictZone={conflicts.some(c => 
                c.track === 1 && trainPositions.some(t => t.track === 1 && t.position >= c.start && t.position <= c.end)
              )} />
              
              {/* Station markers */}
              {stations.map((station) => (
                <div
                  key={station.id}
                  className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 z-10"
                  style={{ left: `${station.position}%` }}
                >
                  <div className="w-5 h-5 bg-[#0A3D62] rounded-full border-3 border-white shadow-lg flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                </div>
              ))}
              
              {/* Trains on Track 1 */}
              {trainPositions
                .filter((train) => train.track === 1)
                .map((train) => (
                  <div key={train.id} className="relative">
                    {/* Delay status tag */}
                    <div
                      className="absolute transform -translate-x-1/2 z-20"
                      style={{ left: `${train.position}%`, top: '-50px' }}
                    >
                      <Badge className={`text-xs px-2 py-1 ${getDelayBadgeColor(train.delay)} border-2 shadow-sm`}>
                        {train.delay === 0 ? 'On Time' : `+${train.delay}m`}
                      </Badge>
                    </div>
                    
                    {/* Train icon with enhanced visuals */}
                    <div
                      className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 z-15"
                      style={{ left: `${train.position}%` }}
                    >
                      <div className="relative flex items-center">
                        {/* Conflict zone glow effect */}
                        {train.status === 'conflict' && (
                          <div className="absolute inset-0 bg-red-400 rounded-lg blur-sm opacity-30 scale-110"></div>
                        )}
                        
                        {getTrainIcon(train.priority, train.direction, train.status)}
                        
                        {/* Direction arrow */}
                        <div className="absolute -top-2 -right-2">
                          {train.direction === 'right' ? (
                            <div className="bg-green-500 rounded-full p-0.5 shadow-sm">
                              <ChevronRight className="h-3 w-3 text-white" />
                            </div>
                          ) : (
                            <div className="bg-green-500 rounded-full p-0.5 shadow-sm">
                              <ChevronLeft className="h-3 w-3 text-white" />
                            </div>
                          )}
                        </div>
                        
                        {/* Conflict indicator */}
                        {train.status === 'conflict' && (
                          <div className="absolute -top-3 -right-3 bg-red-600 rounded-full p-1 shadow-lg border-2 border-white">
                            <AlertTriangle className="h-3 w-3 text-white" />
                          </div>
                        )}
                      </div>
                      
                      {/* Train number label */}
                      <div className="absolute -bottom-10 left-1/2 transform -translate-x-1/2 text-xs font-semibold whitespace-nowrap bg-white px-2 py-1 rounded shadow-md border border-gray-300">
                        {train.name}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
          
          {/* Track 2 (Down Line) */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4 p-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="w-4 h-4 bg-[#FF6B00] rounded"></div>
              <span className="font-medium text-[#FF6B00]">Track 2 (Down Line)</span>
              <ChevronLeft className="h-4 w-4 text-gray-500" />
            </div>
            
            <div className="relative mb-8">
              {/* Conflict zones background for Track 2 */}
              {conflicts.filter(c => c.track === 2).map((conflict, index) => (
                <div
                  key={index}
                  className="absolute h-8 bg-red-200 border-2 border-red-400 rounded-lg opacity-60 shadow-lg"
                  style={{
                    left: `${Math.max(0, conflict.start)}%`,
                    width: `${Math.min(100, conflict.end) - Math.max(0, conflict.start)}%`,
                    top: '-1px'
                  }}
                >
                  <div className="absolute inset-0 bg-red-300 rounded-lg animate-pulse opacity-40"></div>
                </div>
              ))}
              
              {/* Railway Track */}
              <RailwayTrack isConflictZone={conflicts.some(c => 
                c.track === 2 && trainPositions.some(t => t.track === 2 && t.position >= c.start && t.position <= c.end)
              )} />
              
              {/* Station markers */}
              {stations.map((station) => (
                <div
                  key={station.id}
                  className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 z-10"
                  style={{ left: `${station.position}%` }}
                >
                  <div className="w-5 h-5 bg-[#FF6B00] rounded-full border-3 border-white shadow-lg flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                </div>
              ))}
              
              {/* Trains on Track 2 */}
              {trainPositions
                .filter((train) => train.track === 2)
                .map((train) => (
                  <div key={train.id} className="relative">
                    {/* Delay status tag */}
                    <div
                      className="absolute transform -translate-x-1/2 z-20"
                      style={{ left: `${train.position}%`, top: '-50px' }}
                    >
                      <Badge className={`text-xs px-2 py-1 ${getDelayBadgeColor(train.delay)} border-2 shadow-sm`}>
                        {train.delay === 0 ? 'On Time' : `+${train.delay}m`}
                      </Badge>
                    </div>
                    
                    {/* Train icon with enhanced visuals */}
                    <div
                      className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2 z-15"
                      style={{ left: `${train.position}%` }}
                    >
                      <div className="relative flex items-center">
                        {/* Conflict zone glow effect */}
                        {train.status === 'conflict' && (
                          <div className="absolute inset-0 bg-red-400 rounded-lg blur-sm opacity-30 scale-110"></div>
                        )}
                        
                        {getTrainIcon(train.priority, train.direction, train.status)}
                        
                        {/* Direction arrow */}
                        <div className="absolute -top-2 -right-2">
                          {train.direction === 'right' ? (
                            <div className="bg-green-500 rounded-full p-0.5 shadow-sm">
                              <ChevronRight className="h-3 w-3 text-white" />
                            </div>
                          ) : (
                            <div className="bg-green-500 rounded-full p-0.5 shadow-sm">
                              <ChevronLeft className="h-3 w-3 text-white" />
                            </div>
                          )}
                        </div>
                        
                        {/* Conflict indicator */}
                        {train.status === 'conflict' && (
                          <div className="absolute -top-3 -right-3 bg-red-600 rounded-full p-1 shadow-lg border-2 border-white">
                            <AlertTriangle className="h-3 w-3 text-white" />
                          </div>
                        )}
                      </div>
                      
                      {/* Train number label */}
                      <div className="absolute -bottom-10 left-1/2 transform -translate-x-1/2 text-xs font-semibold whitespace-nowrap bg-white px-2 py-1 rounded shadow-md border border-gray-300">
                        {train.name}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
          
          {/* Mini Performance Charts */}
          <MiniCharts />
          
          {/* Enhanced Legend */}
          <div className="bg-white rounded-lg p-4 border border-gray-300 shadow-md hover:shadow-lg transition-shadow">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium mb-3 text-gray-700">Train Types</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ExpressTrainIcon direction="right" status="moving" />
                    <span className="text-sm">Express</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <LocalTrainIcon direction="right" status="moving" />
                    <span className="text-sm">Local</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FreightTrainIcon direction="right" status="moving" />
                    <span className="text-sm">Freight</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3 text-gray-700">Status</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-100 text-green-800 text-xs">On Time</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-yellow-100 text-yellow-800 text-xs">+5m</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <span className="text-sm">Conflict</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3 text-gray-700">Movement</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <ChevronRight className="h-4 w-4 text-gray-600" />
                    <span className="text-sm">Eastbound</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ChevronLeft className="h-4 w-4 text-gray-600" />
                    <span className="text-sm">Westbound</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-1 bg-red-400 rounded"></div>
                    <span className="text-sm">Conflict Zone</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}