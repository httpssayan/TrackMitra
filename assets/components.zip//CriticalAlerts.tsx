import { AlertTriangle, Cloud, Wrench, Radio, X } from 'lucide-react';
import { Badge } from './ui/badge';

interface Alert {
  id: string;
  type: 'weather' | 'maintenance' | 'emergency' | 'technical';
  title: string;
  titleHi: string;
  message: string;
  severity: 'critical' | 'warning' | 'info';
  timestamp: string;
  active: boolean;
}

const alerts: Alert[] = [
  {
    id: '1',
    type: 'emergency',
    title: 'Track Blockage Alert',
    titleHi: 'ट्रैक बाधा चेतावनी',
    message: 'Obstacle detected between GZB-ALG section',
    severity: 'critical',
    timestamp: '14:20',
    active: true
  },
  {
    id: '2', 
    type: 'weather',
    title: 'Fog Warning',
    titleHi: 'कोहरा चेतावनी',
    message: 'Dense fog expected after 18:00, reduce speeds',
    severity: 'warning',
    timestamp: '14:15',
    active: true
  },
  {
    id: '3',
    type: 'maintenance',
    title: 'Scheduled Maintenance',
    titleHi: 'निर्धारित रखरखाव',
    message: 'Track maintenance window: 02:00-04:00',
    severity: 'info',
    timestamp: '13:45',
    active: true
  }
];

function getAlertIcon(type: string) {
  switch (type) {
    case 'weather': return <Cloud className="h-4 w-4" />;
    case 'maintenance': return <Wrench className="h-4 w-4" />;
    case 'emergency': return <AlertTriangle className="h-4 w-4" />;
    case 'technical': return <Radio className="h-4 w-4" />;
    default: return <AlertTriangle className="h-4 w-4" />;
  }
}

function getSeverityColor(severity: string) {
  switch (severity) {
    case 'critical': return 'bg-red-500 text-white animate-pulse';
    case 'warning': return 'bg-yellow-500 text-white';
    case 'info': return 'bg-blue-500 text-white';
    default: return 'bg-gray-500 text-white';
  }
}

function getBorderColor(severity: string) {
  switch (severity) {
    case 'critical': return 'border-l-red-500';
    case 'warning': return 'border-l-yellow-500';
    case 'info': return 'border-l-blue-500';
    default: return 'border-l-gray-500';
  }
}

export function CriticalAlerts() {
  const activeAlerts = alerts.filter(alert => alert.active);
  
  if (activeAlerts.length === 0) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
        <div className="flex items-center gap-2 text-green-700">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="font-medium">All Systems Normal</span>
          <span className="text-sm">सभी सिस्टम सामान्य</span>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-4">
      <div className="bg-[#0A3D62] text-white px-4 py-2 rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-[#FF6B00]" />
            <span className="font-medium">Critical Alerts</span>
            <span className="text-sm text-blue-100">महत्वपूर्ण अलर्ट</span>
          </div>
          <Badge className="bg-red-500 text-white">
            {activeAlerts.length} Active
          </Badge>
        </div>
      </div>
      
      <div className="bg-white border border-gray-300 rounded-b-lg shadow-sm">
        {activeAlerts.map((alert) => (
          <div key={alert.id} className={`border-l-4 ${getBorderColor(alert.severity)} p-3 border-b border-gray-100 last:border-b-0`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <div className={`p-1 rounded ${getSeverityColor(alert.severity)}`}>
                  {getAlertIcon(alert.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-sm text-gray-900">{alert.title}</h4>
                    <span className="text-xs text-gray-500">{alert.titleHi}</span>
                  </div>
                  <p className="text-sm text-gray-700">{alert.message}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">{alert.timestamp}</span>
                <button className="text-gray-400 hover:text-gray-600">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}